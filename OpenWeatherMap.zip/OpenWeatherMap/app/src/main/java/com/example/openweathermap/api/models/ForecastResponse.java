package com.example.openweathermap.api.models;
import com.google.gson.annotations.SerializedName;
import java.util.List;

// Represents the entire JSON response for the 5-day/3-hour forecast API call
public class ForecastResponse {

    // HTTP response code (e.g., "200") - might be String or Integer depending on API/Gson flexibility
    @SerializedName("cod")
    private String cod;

    // Internal parameter - might be message count or other value
    @SerializedName("message")
    private Double message; // Often 0 or a numeric code on success

    @SerializedName("cnt")
    private Integer cnt; // Number of forecast items returned in the list

    @SerializedName("list")
    private List<ForecastItem> list; // The list of forecast items

    @SerializedName("city")
    private City city; // Information about the city

    // --- Getters ---
    public String getCod() {
        return cod;
    }

    public Double getMessage() {
        return message;
    }

    public Integer getCnt() {
        return cnt;
    }

    public List<ForecastItem> getList() {
        return list;
    }

    public City getCity() {
        return city;
    }

    // Optional: equals, hashCode, toString
}
