package com.example.openweathermap.utils;

public class LocationUtils {
}
