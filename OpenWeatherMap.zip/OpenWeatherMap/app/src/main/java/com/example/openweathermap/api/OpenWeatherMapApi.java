package com.example.openweathermap.api;

import com.example.openweathermap.api.models.CurrentWeatherResponse;
import com.example.openweathermap.api.models.ForecastResponse;
import retrofit2.Call; // Import Retrofit Call
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface OpenWeatherMapApi {

    @GET("data/2.5/weather")
    Call<CurrentWeatherResponse> getCurrentWeather( // Return Call<T>
                                                    @Query("lat") double latitude,
                                                    @Query("lon") double longitude,
                                                    @Query("appid") String apiKey,
                                                    @Query("units") String units // Default handled in repository or ViewModel
    );

    @GET("data/2.5/forecast")
    Call<ForecastResponse> getForecast( // Return Call<T>
                                        @Query("lat") double latitude,
                                        @Query("lon") double longitude,
                                        @Query("appid") String apiKey,
                                        @Query("units") String units,
                                        @Query("cnt") int count // Default handled in repository or ViewModel
    );
}
