package com.example.openweathermap;

public final class BuildConfig {
    public static final boolean DEBUG = true; // Or however you determine your debug state
    public static final String OPENWEATHERMAP_API_KEY = getApiKey();

    private static String getApiKey() {
        java.util.Properties properties = new java.util.Properties();
        try {
            properties.load(new java.io.FileInputStream("local.properties"));
            return properties.getProperty("OPENWEATHERMAP_API_KEY");
        } catch (java.io.IOException e) {
            android.util.Log.e("BuildConfig", "Error reading local.properties", e);
            return ""; // Or handle the error as needed
        }
    }
}
