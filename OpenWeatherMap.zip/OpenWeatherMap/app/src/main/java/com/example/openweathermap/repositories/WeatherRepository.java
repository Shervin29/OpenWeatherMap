package com.example.openweathermap.repositories;

import android.content.Context;

import com.example.openweathermap.R;
import com.example.openweathermap.api.OpenWeatherMapApi;
import com.example.openweathermap.api.RetrofitClient;
import com.example.openweathermap.api.models.CurrentWeatherResponse;
import com.example.openweathermap.api.models.ForecastResponse;

import retrofit2.Call;

/**
 * Repository class responsible for interacting with OpenWeatherMap API.
 */
public class WeatherRepository {

    private final OpenWeatherMapApi apiService;
    private final String apiKey;
    private final String units = "metric"; // Default units (metric = Celsius)
    private final int forecastCount = 40;  // Default number of forecast entries

    /**
     * Default constructor initializing with the real API service.
     *
     * @param context needed to access API key from resources
     */
    public WeatherRepository(Context context) {
        this.apiService = RetrofitClient.getApiService();
        this.apiKey = context.getString(R.string.openweathermap_api_key); // ✅ Getting from secrets.xml
    }

    /**
     * Constructor for injecting a mock or custom API service (used for testing).
     */
    public WeatherRepository(OpenWeatherMapApi apiService, Context context) {
        this.apiService = apiService;
        this.apiKey = context.getString(R.string.openweathermap_api_key);
    }

    /**
     * Fetch current weather for the specified latitude and longitude.
     *
     * @param lat latitude
     * @param lon longitude
     * @return a Call object to get CurrentWeatherResponse
     */
    public Call<CurrentWeatherResponse> getCurrentWeather(double lat, double lon) {
        return apiService.getCurrentWeather(lat, lon, apiKey, units);
    }

    /**
     * Fetch weather forecast for the specified latitude and longitude.
     *
     * @param lat latitude
     * @param lon longitude
     * @return a Call object to get ForecastResponse
     */
    public Call<ForecastResponse> getForecast(double lat, double lon) {
        return apiService.getForecast(lat, lon, apiKey, units, forecastCount);
    }
}
