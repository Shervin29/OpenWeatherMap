package com.example.openweathermap.utils;

public class Constants {
    public static final String OPENWEATHERMAP_BASE_URL = "https://api.openweathermap.org/";
    // Add other constants if needed
}
