package com.example.openweathermap.api.models;

import com.google.gson.annotations.SerializedName;

// Represents the 'sys' object within a forecast item
public class Sys {

    @SerializedName("pod")
    private String pod; // Part of day (d for day, n for night)

    // Getter
    public String getPod() {
        return pod;
    }

    // Optional: equals, hashCode, toString
}
