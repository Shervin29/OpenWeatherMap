package com.example.openweathermap.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import java.util.Objects;
import com.bumptech.glide.Glide; // Import Glide
import com.example.openweathermap.R;
import com.example.openweathermap.api.models.ForecastItem;
import com.example.openweathermap.api.models.Weather;
import com.example.openweathermap.databinding.ItemForecastBinding; // Import ViewBinding

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone; // Consider TimeZone if needed

public class ForecastAdapter extends ListAdapter<ForecastItem, ForecastAdapter.ForecastViewHolder> {

    // Make formatters static or instance variables if thread safety is not a concern here
    // Or use java.time API if minSdk allows (API 26+)
    private static final SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
    private static final SimpleDateFormat outputFormat = new SimpleDateFormat("EEE, MMM d, h:mm a", Locale.getDefault());

    public ForecastAdapter() {
        super(DIFF_CALLBACK);
    }

    @NonNull
    @Override
    public ForecastViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemForecastBinding binding = ItemForecastBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new ForecastViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ForecastViewHolder holder, int position) {
        ForecastItem item = getItem(position);
        if (item != null) {
            holder.bind(item);
        }
    }

    // Inner ViewHolder class
    static class ForecastViewHolder extends RecyclerView.ViewHolder {
        private final ItemForecastBinding binding; // Use ViewBinding

        ForecastViewHolder(@NonNull ItemForecastBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        void bind(ForecastItem item) {
            Context context = itemView.getContext(); // Get context from itemView

            // Date & Time Formatting (with null checks)
            String displayDateTime = "N/A";
            if (item.getDtTxt() != null) {
                try {
                    Date date = inputFormat.parse(item.getDtTxt());
                    if (date != null) {
                        // Consider setting TimeZone on outputFormat if needed
                        displayDateTime = outputFormat.format(date);
                    } else {
                        displayDateTime = item.getDtTxt(); // Fallback
                    }
                } catch (ParseException e) {
                    displayDateTime = item.getDtTxt(); // Fallback to raw string on parse error
                }
            } else if (item.getDt() != null) { // Fallback using timestamp
                try {
                    Date date = new Date(item.getDt() * 1000L); // OWM uses seconds
                    displayDateTime = outputFormat.format(date);
                } catch (Exception e) { /* Ignore */ }
            }
            binding.itemForecastDatetime.setText(displayDateTime);

            // Temperature Formatting
            String tempText = "N/A";
            if (item.getMain() != null && item.getMain().getTemp() != null) {
                int temp = (int) Math.round(item.getMain().getTemp());
                tempText = context.getString(R.string.info_temp_format_value, temp); // Use string resource
            }
            binding.itemForecastTemp.setText(tempText);

            // Description Formatting
            String descText = "N/A";
            Weather weather = null;
            if(item.getWeather() != null && !item.getWeather().isEmpty()) {
                weather = item.getWeather().get(0);
            }
            if (weather != null && weather.getDescription() != null) {
                String rawDesc = weather.getDescription();
                // Capitalize first letter
                descText = rawDesc.substring(0, 1).toUpperCase(Locale.getDefault()) + rawDesc.substring(1);
            }
            binding.itemForecastDescription.setText(descText);

            // Icon Loading (using Glide)
            String iconCode = (weather != null) ? weather.getIcon() : null;
            if (iconCode != null) {
                String iconUrl = "https://openweathermap.org/img/wn/" + iconCode + "@2x.png";
                Glide.with(context)
                        .load(iconUrl)
                        .placeholder(R.mipmap.ic_launcher) // Placeholder
                        .error(R.mipmap.ic_launcher)       // Error fallback
                        .into(binding.itemForecastIcon);
            } else {
                binding.itemForecastIcon.setImageResource(R.mipmap.ic_launcher); // Default
            }
        }
    }

    // DiffUtil.ItemCallback
    private static final DiffUtil.ItemCallback<ForecastItem> DIFF_CALLBACK =
            new DiffUtil.ItemCallback<ForecastItem>() {
                @Override
                public boolean areItemsTheSame(@NonNull ForecastItem oldItem, @NonNull ForecastItem newItem) {
                    // dt (timestamp) should be unique
                    return oldItem.getDt() != null && oldItem.getDt().equals(newItem.getDt());
                }

                @Override
                public boolean areContentsTheSame(@NonNull ForecastItem oldItem, @NonNull ForecastItem newItem) {
                    // Use equals method if implemented in POJO, otherwise compare relevant fields
                    // This relies on a proper equals implementation in ForecastItem POJO
                    // return oldItem.equals(newItem);
                    // Manual comparison if equals not overridden:
                    return Objects.equals(oldItem.getDtTxt(), newItem.getDtTxt()) &&
                            Objects.equals(oldItem.getMain(), newItem.getMain()) && // Requires Main.equals()
                            Objects.equals(oldItem.getWeather(), newItem.getWeather()); // Requires List<Weather>.equals()
                }
            };
    // Need to implement .equals() and .hashCode() in POJOs (Main, Weather, ForecastItem) for content comparison.
}
