package com.example.openweathermap.activities;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.util.Log; // For logging
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider; // Import ViewModelProvider

import com.bumptech.glide.Glide;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.openweathermap.R;
import com.example.openweathermap.ResultWrapper; // Import wrapper
import com.example.openweathermap.api.models.CurrentWeatherResponse;
import com.example.openweathermap.api.models.Weather;
import com.example.openweathermap.databinding.ActivityMapsBinding; // Import ViewBinding
import com.example.openweathermap.databinding.InfoWindowWeatherBinding;
import com.example.openweathermap.viewmodels.MapsViewModel;

import java.util.List;
import java.util.Locale;
import java.util.Map; // For permission results map
import java.util.Objects;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback {

    private static final String TAG = "MapsActivity"; // Logging tag

    private GoogleMap mMap;
    private ActivityMapsBinding binding; // ViewBinding instance
    private MapsViewModel mapsViewModel;

    private Location lastKnownLocation = null; // Store user's location
    private Marker currentDisplayedMarker = null; // Keep track of the current marker

    // Permission Launcher
    private final ActivityResultLauncher<String[]> locationPermissionRequest =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                Boolean fineLocationGranted = result.getOrDefault(
                        Manifest.permission.ACCESS_FINE_LOCATION, false);
                Boolean coarseLocationGranted = result.getOrDefault(
                        Manifest.permission.ACCESS_COARSE_LOCATION, false);

                if (fineLocationGranted != null && fineLocationGranted) {
                    // Precise location access granted.
                    getLastKnownLocationAndSetupMap();
                } else if (coarseLocationGranted != null && coarseLocationGranted) {
                    // Only approximate location access granted.
                    getLastKnownLocationAndSetupMap();
                } else {
                    // No location access granted.
                    Toast.makeText(this, "Location permission denied. Map centered on default.", Toast.LENGTH_LONG).show();
                    setupMapWithDefaultLocation();
                }
            });


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Initialize ViewModel
        mapsViewModel = new ViewModelProvider(this).get(MapsViewModel.class);

        // Obtain the SupportMapFragment and get notified when the map is ready.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map_fragment_container);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        } else {
            Log.e(TAG, "SupportMapFragment not found!");
            Toast.makeText(this, "Error initializing map.", Toast.LENGTH_LONG).show();
            finish(); // Close activity if map fragment isn't found
        }

        setupObservers();
        setupUIListeners();
        checkLocationPermission(); // Start permission check/location fetch
    }

    // --- Map Ready Callback ---
    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        if (mMap != null) { // Add this check for extra safety
            Log.d(TAG, "Map Ready");
            mMap.getUiSettings().setZoomControlsEnabled(true);


            // Set custom InfoWindow Adapter
            mMap.setInfoWindowAdapter(new CustomInfoWindowAdapter(this));

            // Set map click listener
            mMap.setOnMapClickListener(latLng -> {
                Log.d(TAG, "Map clicked at: " + latLng);
                binding.progressBarMaps.setVisibility(View.VISIBLE);
                if (currentDisplayedMarker != null) {
                    currentDisplayedMarker.remove(); // Remove previous marker
                }
                // Add a temporary marker
                currentDisplayedMarker = mMap.addMarker(new MarkerOptions()
                        .position(latLng)
                        .title("Loading weather..."));

                if (currentDisplayedMarker != null) {
                    currentDisplayedMarker.setTag(null); // Clear old data
                    currentDisplayedMarker.showInfoWindow(); // Show temp title
                }
                mapsViewModel.fetchWeatherForCoordinates(latLng); // Fetch weather
            });

            // Check if location is already available or permissions granted
            if (lastKnownLocation != null) {
                moveCameraToLocation(lastKnownLocation, 14f);
                enableLocationFeatures();
            } else if (hasLocationPermission()) {
                enableLocationFeatures(); // Enable blue dot if permission exists but location fetch pending/failed
            } else {
                // Handle case where permissions were denied before map was ready
                setupMapWithDefaultLocation();
            }
        } else {
            Log.e(TAG, "GoogleMap object is null in onMapReady!");
        }
    }

    // --- Setup ---
    private void setupObservers() {
        // Observe User's Current Location
        mapsViewModel.currentLocation.observe(this, result -> {
            if (result == null) return;

            switch (result.status) {
                case LOADING:
                    binding.progressBarMaps.setVisibility(View.VISIBLE);
                    break;
                case SUCCESS:
                    binding.progressBarMaps.setVisibility(View.GONE);
                    lastKnownLocation = result.data; // Store location
                    binding.buttonViewForecast.setEnabled(true); // Enable forecast button
                    if (result.data != null && mMap != null) {
                        Log.d(TAG, "Current location success: " + result.data);
                        moveCameraToLocation(result.data, 14f);
                        enableLocationFeatures();
                    } else {
                        Log.w(TAG, "Current location success but data or map is null.");
                        if (mMap != null) setupMapWithDefaultLocation();
                    }
                    break;
                case ERROR:
                    binding.progressBarMaps.setVisibility(View.GONE);
                    binding.buttonViewForecast.setEnabled(false); // Keep forecast disabled
                    Toast.makeText(this, "Error getting your location: " + result.message, Toast.LENGTH_LONG).show();
                    Log.e(TAG, "Error getting location: " + result.message, result.error);
                    if (mMap != null) {
                        setupMapWithDefaultLocation();
                    }
                    break;
            }
        });

        // Observe Weather for Tapped Location
        mapsViewModel.tappedLocationWeather.observe(this, result -> {
            if (result == null) return;
            binding.progressBarMaps.setVisibility(View.GONE); // Hide progress bar after attempt

            switch (result.status) {
                case LOADING:
                    // Usually handled by the temporary marker title
                    break;
                case SUCCESS:
                    Log.d(TAG, "Tapped location weather success.");
                    if (currentDisplayedMarker != null && result.data != null) {
                        currentDisplayedMarker.setTag(result.data); // Attach data
                        currentDisplayedMarker.setTitle(result.data.getName() != null ? result.data.getName() : "Weather Info");
                        currentDisplayedMarker.showInfoWindow(); // Refresh
                    }
                    break;
                case ERROR:
                    Log.e(TAG, "Error getting tapped location weather: " + result.message, result.error);
                    Toast.makeText(this, "Error fetching weather: " + result.message, Toast.LENGTH_LONG).show();
                    if (currentDisplayedMarker != null) {
                        currentDisplayedMarker.setTag(result.message); // Attach error message
                        currentDisplayedMarker.setTitle("Error");
                        currentDisplayedMarker.showInfoWindow(); // Refresh
                    }
                    break;
            }
        });
    }

    private void setupUIListeners() {
        binding.buttonViewForecast.setEnabled(false); // Disable initially
        binding.buttonViewForecast.setOnClickListener(v -> {
            if (lastKnownLocation != null) {
                Intent intent = new Intent(MapsActivity.this, ForecastActivity.class);
                intent.putExtra(ForecastActivity.EXTRA_LATITUDE, lastKnownLocation.getLatitude());
                intent.putExtra(ForecastActivity.EXTRA_LONGITUDE, lastKnownLocation.getLongitude());
                startActivity(intent);
            } else {
                Toast.makeText(this, "Your location is not available yet.", Toast.LENGTH_SHORT).show();
                // Optionally re-trigger permission check / location fetch
                // checkLocationPermission();
            }
        });
    }

    // --- Location & Permissions ---
    private void checkLocationPermission() {
        if (hasLocationPermission()) {
            getLastKnownLocationAndSetupMap();
        } else {
            // Request permissions
            Log.d(TAG, "Requesting location permissions.");
            locationPermissionRequest.launch(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            });
        }
    }

    private boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED;
    }

    @SuppressLint("MissingPermission") // Called only after permission check succeeds
    private void getLastKnownLocationAndSetupMap() {
        Log.d(TAG, "Permission granted. Fetching location.");
        binding.progressBarMaps.setVisibility(View.VISIBLE);
        mapsViewModel.fetchCurrentLocation(); // ViewModel handles fetching
    }

    @SuppressLint("MissingPermission") // Called only after permission check succeeds
    private void enableLocationFeatures() {
        if (mMap != null && hasLocationPermission()) {
            try {
                mMap.setMyLocationEnabled(true); // Show blue dot
                mMap.getUiSettings().setMyLocationButtonEnabled(true); // Show button
                Log.d(TAG, "MyLocation layer enabled.");
            } catch (SecurityException e) {
                Log.e(TAG, "SecurityException enabling location features.", e);
            }
        }
    }

    // --- Map Camera & Default ---
    private void moveCameraToLocation(@NonNull Location location, float zoomLevel) {
        if (mMap != null) {
            LatLng userLatLng = new LatLng(location.getLatitude(), location.getLongitude());
            Log.d(TAG, "Moving camera to: " + userLatLng + " with zoom: " + zoomLevel);
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(userLatLng, zoomLevel));
        }
    }

    private void setupMapWithDefaultLocation() {
        if (mMap != null) {
            // Default to Toronto, Ontario
            LatLng defaultLocation = new LatLng(43.6532, -79.3832);
            Log.d(TAG, "Setting up map with default location: Toronto");
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 10f)); // Zoom level 10
        }
    }

    // --- Custom Info Window Adapter ---
    static class CustomInfoWindowAdapter implements GoogleMap.InfoWindowAdapter {
        // Use ViewBinding for the info window layout
        private final InfoWindowWeatherBinding binding;
        private final LayoutInflater inflater;

        // Pass context or inflater from Activity
        CustomInfoWindowAdapter(MapsActivity activity) {
            this.inflater = LayoutInflater.from(activity);
            // Inflate here, reuse the binding object
            this.binding = InfoWindowWeatherBinding.inflate(inflater, null, false);
        }


        @Nullable
        @Override
        public View getInfoWindow(@NonNull Marker marker) {
            // Return null to use the default frame with custom contents from getInfoContents.
            // If you return the view here, getInfoContents is ignored.
            return null;
        }

        @Nullable
        @Override
        public View getInfoContents(@NonNull Marker marker) {
            // Get data attached to the marker
            Object tag = marker.getTag();

            if (tag instanceof CurrentWeatherResponse) {
                CurrentWeatherResponse data = (CurrentWeatherResponse) tag;
                binding.infoTitle.setText(data.getName() != null ? data.getName() : marker.getTitle());

                String tempText = "N/A";
                if (data.getMain() != null && data.getMain().getTemp() != null) {
                    int temp = (int) Math.round(data.getMain().getTemp());
                    tempText = binding.getRoot().getContext().getString(R.string.info_temp_format_value, temp);
                }
                binding.infoTemperature.setText(tempText);

                String descText = "N/A";
                Weather weather = null;
                if(data.getWeather() != null && !data.getWeather().isEmpty()) {
                    weather = data.getWeather().get(0);
                }
                if (weather != null && weather.getDescription() != null) {
                    String rawDesc = weather.getDescription();
                    descText = rawDesc.substring(0, 1).toUpperCase(Locale.getDefault()) + rawDesc.substring(1);
                }
                binding.infoDescription.setText(binding.getRoot().getContext().getString(R.string.info_desc_format, descText));


                // Icon
                String iconCode = (weather != null) ? weather.getIcon() : null;
                if (iconCode != null) {
                    binding.infoIcon.setVisibility(View.VISIBLE);
                    String iconUrl = "https://openweathermap.org/img/wn/" + iconCode + "@2x.png";
                    Glide.with(binding.getRoot().getContext())
                            .load(iconUrl)
                            .error(R.drawable.ic_launcher_foreground) // Use appropriate placeholder/error
                            .into(binding.infoIcon);
                } else {
                    binding.infoIcon.setVisibility(View.GONE);
                }

            } else if (tag instanceof String) { // Assume error message string
                binding.infoTitle.setText("Error");
                binding.infoTemperature.setText((String) tag);
                binding.infoDescription.setText("");
                binding.infoIcon.setVisibility(View.GONE);
            } else { // Loading or unknown state
                binding.infoTitle.setText(marker.getTitle() != null ? marker.getTitle() : "Loading...");
                binding.infoTemperature.setText("...");
                binding.infoDescription.setText("...");
                binding.infoIcon.setVisibility(View.GONE);
            }

            return binding.getRoot(); // Return the populated root view
        }
    }
}